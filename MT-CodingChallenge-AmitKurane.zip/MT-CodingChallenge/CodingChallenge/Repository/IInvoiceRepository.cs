﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{
    public interface IInvoiceRepository
    {
        decimal? GetTotal(int invoiceId);

        decimal GetTotalOfUnpaid();

        IReadOnlyDictionary<string, long> GetItemsReport(DateTime? from, DateTime? to);

    }
}
