﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingChallenge
{
    public class InvoiceRepository : IInvoiceRepository
    {
        private readonly IQueryable<Invoice> _invoices;

        public InvoiceRepository(IQueryable<Invoice> invoices)
        {
            this._invoices = invoices ?? throw new ArgumentNullException("Missing Invoices");
        }

        /// <summary>
        /// Should return a total value of an invoice with a given id. If an invoice does not exist null should be returned.
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        public decimal? GetTotal(int invoiceId)
        {
            var invoice = _invoices.SingleOrDefault(i => i.Id == invoiceId);
            
            return invoice?.InvoiceItems.Sum(ii => ii.Price) ;
        }

        /// <summary>
        /// Should return a total value of all unpaid invoices.
        /// </summary>
        /// <returns></returns>
        public decimal GetTotalOfUnpaid()
        {
            return _invoices.Where(i=>!i.AcceptanceDate.HasValue) //check if acceptance date is null, means it is unpaid
                    .Select (s=> new { s.Id, Total = s.InvoiceItems.Sum(i => i.Price) }) //sum of all pricess for all invoiceitems under specific invoice
                    .Sum(x => x.Total); //Sum of all invoices total

        }

        /// <summary>
        /// Should return a dictionary where the name of an invoice item is a key and the number of bought items is a value.
        /// The number of bought items should be summed within a given period of time (from, to). Both the from date and the end date can be null.
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public IReadOnlyDictionary<string, long> GetItemsReport(DateTime? from, DateTime? to)
        {
            DateTime? frm = from.HasValue ? from : DateTime.MinValue;
            DateTime? td = to.HasValue ? to : DateTime.MaxValue;

            return _invoices.Where(i => i.CreationDate >= frm && i.CreationDate <= td) //get all invoices between from and to date range
                                .SelectMany(x => x.InvoiceItems)                        // select all invoice items
                                .GroupBy(ii => ii.Name)                                 //group by item name
                                .Select(n => new { Name = n.Key, Count = n.Sum(c => c.Count)}) //sum of item count group by item name
                                .ToDictionary(d=>d.Name,d=>d.Count);                    //convert to dictionary
        }
    }
}
