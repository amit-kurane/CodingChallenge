﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CodingChallenge
{
    public class Program
    {
        public static void Main(string[] args)
        {
            IInvoiceRepository invoicerepository = new InvoiceRepository(CreateInvoiceData());

            Console.WriteLine("Total Amount :" + invoicerepository.GetTotal(100));
            Console.WriteLine("Total Unpaid Amount :" + invoicerepository.GetTotalOfUnpaid());
            Console.WriteLine("Items Report");
            foreach (var item in invoicerepository.GetItemsReport(null, null))
                Console.WriteLine("\t" + item.Key + " : " + item.Value);

            Console.Read();
        }

        /// <summary>
        /// Main Invoice Repository for unit testing
        /// </summary>
        /// <returns></returns>
        public static IQueryable<Invoice> CreateInvoiceData()
        {
            List<Invoice> invoices = new List<Invoice>()
            {
                new Invoice()
                {
                    Id=100, Description="Grocery1", Number="134/10/2018"
                    ,Seller="Mert-Anderson, 600 Hickman Street, Illinois",Buyer="John-Smith, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("2020-10-15"),AcceptanceDate=null
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                    },
                },
                new Invoice()
                {
                    Id=2000, Description="Grocery2", Number="134/10/2019"
                    ,Seller="Mert-Anderson-I, 700 Hickman Street, Illinois",Buyer="John-Smith-I, 4285 Deercove Drive, Georgia"
                    ,CreationDate=Convert.ToDateTime("2018-01-04"),AcceptanceDate=Convert.ToDateTime("2021-10-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                        new InvoiceItem() { Name="cheese",Count=3,Price=30.75M },
                    },
                },
                new Invoice()
                {
                    Id=3, Description="Grocery3", Number="134/10/2017"
                    ,Seller="Mert-Anderson-II, 800 Hickman Street, Illinois",Buyer="John-Smith-II, 4285 Deercove Drive, NY"
                    ,CreationDate=Convert.ToDateTime("2015-05-15"),AcceptanceDate=null
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                    },
                },
                new Invoice()
                {
                    Id=40, Description="Grocery4", Number="145/10/2020"
                    ,Seller="Mert-Anderson-III, 300 Ashford Gables, Illinois",Buyer="John-Smith-III, 4285 Deercove Drive, NJ"
                    ,CreationDate=Convert.ToDateTime("2000-03-16"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                },
                new Invoice()
                {
                    Id=50, Description="Grocery5", Number="120/10/2016"
                    ,Seller="Mert-Anderson-XX, 400 Hickman Street, Illinois",Buyer="John-Smith-XX, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("1998-05-18"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                       new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                       new InvoiceItem() { Name="cheese",Count=3,Price=30.75M },
                    },
                },
                new Invoice()
                {
                    Id=6, Description="Grocery6", Number="145/20/2018"
                    ,Seller="Mert-XXXX, 600 Hickman Gables, Illinois",Buyer="John-Smith-XXXX, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("2021-03-16"),AcceptanceDate=null
                    ,InvoiceItems =
                new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                    },
                },
                new Invoice()
                {
                    Id=7, Description="Grocery7", Number="134/50/2008"
                    ,Seller="Mert-YYY, 200 Hickman Street, Illinois",Buyer="John-Smith-YYYY, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("1990-03-16"),AcceptanceDate=Convert.ToDateTime("192-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                    },
                },
                new Invoice()
                {
                    Id=8, Description="Grocery8", Number="134/10/2005"
                    ,Seller="Mert-Anderson-ZZZ, 300 Hickman Street, Illinois",Buyer="John-ZZZ, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("2005-03-16"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="cheese",Count=3,Price=30.75M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                    },
                },
                new Invoice()
                {
                    Id=9, Description="Grocery9", Number="100/10/2004"
                    ,Seller="ABC BBB, 600 JFK Street, Illinois",Buyer="John-ABC, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("2004-03-16"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="cheese",Count=15,Price=150M },
                    },
                },
                new Invoice()
                {
                    Id=10, Description="Grocery10", Number="111/11/2011"
                    ,Seller="Mert-Mackoy, 600 Ashford Street, Illinois",Buyer="John-Carter, 4285 Deercove Drive, Georgia"
                    ,CreationDate=Convert.ToDateTime("2018-01-04"),AcceptanceDate=null
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                        new InvoiceItem() { Name="cheese",Count=5,Price=70M },
                    },
                },
            };

            return invoices.AsQueryable();
        }

        /// <summary>
        /// Invoice Repository for All Invoices accepted unit testing
        /// </summary>
        /// <returns></returns>
        public static IQueryable<Invoice> CreateInvoiceDataWithAllInvoiceAccepted()
        {
            List<Invoice> invoices = new List<Invoice>()
            {
                new Invoice()
                {
                    Id=2000, Description="Grocery2", Number="134/10/2019"
                    ,Seller="Mert-Anderson-I, 700 Hickman Street, Illinois",Buyer="John-Smith-I, 4285 Deercove Drive, Georgia"
                    ,CreationDate=Convert.ToDateTime("2018-01-04"),AcceptanceDate=Convert.ToDateTime("2021-10-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="milk",Count=20,Price=60.23M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                        new InvoiceItem() { Name="cheese",Count=3,Price=30.75M },
                    },
                },
                new Invoice()
                {
                    Id=40, Description="Grocery4", Number="145/10/2020"
                    ,Seller="Mert-Anderson-III, 300 Ashford Gables, Illinois",Buyer="John-Smith-III, 4285 Deercove Drive, NJ"
                    ,CreationDate=Convert.ToDateTime("2000-03-16"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                },
                new Invoice()
                {
                    Id=50, Description="Grocery5", Number="120/10/2016"
                    ,Seller="Mert-Anderson-XX, 400 Hickman Street, Illinois",Buyer="John-Smith-XX, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("1998-05-18"),AcceptanceDate=Convert.ToDateTime("2005-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                       new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                       new InvoiceItem() { Name="cheese",Count=3,Price=30.75M },
                    },
                },
                new Invoice()
                {
                    Id=7, Description="Grocery7", Number="134/50/2008"
                    ,Seller="Mert-YYY, 200 Hickman Street, Illinois",Buyer="John-Smith-YYYY, 4285 Deercove Drive, Dallas"
                    ,CreationDate=Convert.ToDateTime("1990-03-16"),AcceptanceDate=Convert.ToDateTime("192-03-25")
                    ,InvoiceItems =
                    new List<InvoiceItem>()
                    {
                        new InvoiceItem() { Name="eggs",Count=10,Price=20.5M },
                        new InvoiceItem() { Name="bread",Count=100,Price=250.75M },
                    },
                },
            };

            return invoices.AsQueryable();
        }
    }
}
