1. Console Application (C#) is created in Visual Studio 2019 with Framework .NET 5.0
2. Test project (mstest) is created in Visual Studio 2019 with Framework .NET 5.0 