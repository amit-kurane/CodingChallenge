using Microsoft.VisualStudio.TestTools.UnitTesting;
using CodingChallenge;
using System.Collections.Generic;
using System.Linq;
using System;


namespace CodingChallenge.Tests
{
    [TestClass]
    public class InvoiceRepositoryTests
    {
        [TestMethod]
        public void GetTotal_NoInvoices_NullShouldbeReturned()
        {
            //Assign
            var invoiceid = 4;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetTotal_NoInvoicesWithNegativeInvoiceID_NullShouldbeReturned()
        {
            //Assign
            var invoiceid = -1;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetTotal_NoInvoicesWithBigNegativeInvoiceID_NullShouldbeReturned()
        {
            //Assign
            var invoiceid = int.MinValue;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetTotal_NoInvoicesWithBigInvoiceID_NullShouldbeReturned()
        {
            //Assign
            var invoiceid = int.MaxValue;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.IsNull(result);
        }

        [TestMethod]
        public void GetTotal_InvoicesExists_CorrectValueShouldbeReturned()
        {
            //Assign
            var invoiceid = 100;
            decimal? ExpectedResult = 331.48M;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.AreEqual(ExpectedResult, result);
        }

        [TestMethod]
        public void GetTotal_InvoicesExistsWithoutInvoiceItems_CorrectValueShouldbeReturned()
        {
            //Assign
            var invoiceid = 40;
            decimal? ExpectedResult = 0M;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotal(invoiceid);

            //Assert
            Assert.AreEqual(ExpectedResult, result);
        }

        [TestMethod]
        public void GetItemReports_NoInvoicesWithDateRange_EmptyReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = Convert.ToDateTime("2018-01-02"), todt = Convert.ToDateTime("2018-01-03");
            var ExpectedCount = 0;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
        }

        [TestMethod]
        public void GetItemReports_InvoicesExists_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = Convert.ToDateTime("2018-01-03"), todt = Convert.ToDateTime("2018-01-04");
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 20);
            dct.Add("milk", 40);
            dct.Add("bread", 200);
            dct.Add("cheese", 8);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistwithNULLFromAndToDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = null, todt = null;
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 60);
            dct.Add("milk", 120);
            dct.Add("bread", 700);
            dct.Add("cheese", 29);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistswithSameFromandToDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = Convert.ToDateTime("2018-01-04"), todt = Convert.ToDateTime("2018-01-04");
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 20);
            dct.Add("milk", 40);
            dct.Add("bread", 200);
            dct.Add("cheese", 8);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistswithFromDateGreaterthanToDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = Convert.ToDateTime("2018-01-05"), todt = Convert.ToDateTime("2018-01-04");
            var ExpectedCount = 0;
            Dictionary<string, long> dct = new();

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistsWithMinFromDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = DateTime.MinValue, todt = Convert.ToDateTime("2018-01-01");
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 30);
            dct.Add("milk", 40);
            dct.Add("bread", 300);
            dct.Add("cheese", 21);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistsWithNULLFromDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt =null, todt = Convert.ToDateTime("2018-01-01");
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 30);
            dct.Add("milk", 40);
            dct.Add("bread", 300);
            dct.Add("cheese", 21);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistsWithNULLToDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = Convert.ToDateTime("2020-01-01"), todt = null;
            var ExpectedCount = 3;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 10);
            dct.Add("milk", 40);
            dct.Add("bread", 200);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetItemReports_InvoicesExistsWithMinFromDateandMaxToDate_CorrectReportShouldbeReturned()
        {
            //Assign
            DateTime? fromdt = DateTime.MinValue, todt = DateTime.MaxValue;
            var ExpectedCount = 4;
            Dictionary<string, long> dct = new();
            dct.Add("eggs", 60);
            dct.Add("milk", 120);
            dct.Add("bread", 700);
            dct.Add("cheese", 29);

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetItemsReport(fromdt, todt);

            //Assert
            Assert.AreEqual(ExpectedCount, result.Count);
            CollectionAssert.AreEquivalent(dct.ToList(), result.ToList());
        }

        [TestMethod]
        public void GetTotalofUnpaid_NoInvoices_ZeroShouldbeReturned()
        {
            //Assign
            var ExpectedResult = 0M;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceDataWithAllInvoiceAccepted());
            var result = invoicerepository.GetTotalOfUnpaid();

            //Assert
            Assert.AreEqual(ExpectedResult,result);
        }

        [TestMethod]
        public void GetTotalofUnpaid_InvoicesExists_CorrectValueShouldbeReturned()
        {
            //Assign
            var ExpectedResult = 1124.67M;

            //Act
            IInvoiceRepository invoicerepository = new InvoiceRepository(Program.CreateInvoiceData());
            var result = invoicerepository.GetTotalOfUnpaid();

            //Assert
            Assert.AreEqual(ExpectedResult, result);
        }

        [TestMethod]
        public void Constructor_NULLInputParameter_ExceptionShouldBeReturned()
        {
            //Assign

            //Act
             
            //Assert
            Assert.ThrowsException<ArgumentNullException>(()=>new InvoiceRepository(null));
        }
    }
}
