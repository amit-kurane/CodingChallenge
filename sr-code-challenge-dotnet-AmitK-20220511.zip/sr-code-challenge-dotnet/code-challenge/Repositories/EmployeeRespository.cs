﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using challenge.Models;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;
using challenge.Data;

namespace challenge.Repositories
{
    public class EmployeeRespository : IEmployeeRepository
    {
        private readonly EmployeeContext _employeeContext;
        private readonly ILogger<IEmployeeRepository> _logger;

        public EmployeeRespository(ILogger<IEmployeeRepository> logger, EmployeeContext employeeContext)
        {
            _employeeContext = employeeContext;
            _logger = logger;
        }

        public Employee Add(Employee employee)
        {
            employee.EmployeeId = Guid.NewGuid().ToString();
            _employeeContext.Employees.Add(employee);
            return employee;
        }

        public Employee GetById(string id)
        {
            return _employeeContext.Employees.SingleOrDefault(e => e.EmployeeId == id);
        }

        public Task SaveAsync()
        {
            return _employeeContext.SaveChangesAsync();
        }

        public Employee Remove(Employee employee)
        {
            return _employeeContext.Remove(employee).Entity;
        }

        /// <summary>
        /// Get Number of Reportees for respective employee
        /// </summary>
        /// <param name="id">Employee ID</param>
        /// <returns>ReportingStructure object with Employee and No</returns>
        public ReportingStructure GetReportingById(string id)
        {
            var reportingStructure = (from emp in _employeeContext.Employees
                                      where emp.EmployeeId == id
                                      select new ReportingStructure
                                      {
                                          Employee = emp,
                                          NumberOfReports = RecursiveReport(_employeeContext.Employees.Where(e => e.EmployeeId == id).SelectMany(l => l.DirectReports))
                                      }).FirstOrDefault();

            return reportingStructure;

        }

        /// <summary>
        /// Recursive call to get the drill down level of direct reporties
        /// </summary>
        /// <param name="source">direct report list</param>
        /// <returns>number of direct reportee</returns>
        private int RecursiveReport(IEnumerable<Employee> source)
        {
            int Count = 0;
            //for each child member dril-down to its direct reportee and increase count by 1
            foreach (var item in source)
                Count += RecursiveReport(_employeeContext.Employees.Where(e => e.EmployeeId == item.EmployeeId).SelectMany(l => l.DirectReports)) + 1;
            return Count;
        }

        /// <summary>
        /// Add compensation (Salary and Effective Date) for respective employee
        /// </summary>
        /// <param name="compensation"></param>
        /// <returns>Compensation object with Employee, Salary and Eff date </returns>
        public Compensation AddCompensation(Compensation compensation)
        {
            compensation.CompensationId = Guid.NewGuid().ToString();
            _employeeContext.Compensations.Add(compensation);
            _employeeContext.Entry(compensation.Employee).State = EntityState.Unchanged; // set parent as unchanged
            return compensation;
        }

        /// <summary>
        /// Get Compensation for asked employee
        /// </summary>
        /// <param name="id">Empployee ID</param>
        /// <returns>List of compensation objects with Empoyee, Salary and Eff date</returns>
        public List<Compensation> GetCompensationById(string id)
        {
            return _employeeContext.Compensations.Where(e => e.Employee.EmployeeId == id).Include(e=>e.Employee).ToList();
            //return _employeeContext.Compensations.Where(e => e.Employee.EmployeeId == id).ToList();
        }
    }
}
